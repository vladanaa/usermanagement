package com.vladana.proba.service;

import com.vladana.proba.entity.Company;
import com.vladana.proba.repository.CompanyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyService {

    @Autowired
    private CompanyRepo cr;

    public Company addCompany(Company company){
        return cr.save(company);
    }

    public List<Company> addCompanies(List<Company> companies){

        return cr.saveAll(companies);
    }

    public List<Company> getCompanies(){

        return cr.findAll();
    }

    public String deleteCompany(int id){
        cr.deleteById(id);
        return "Company with ID " + id + "succesfully deleted";
    }

    public Company updateCompany(Company company) {
        Company temp = cr.findById(company.getId()).orElse(null);
        temp.setName(company.getName());
        return cr.save(temp);
    }


}
