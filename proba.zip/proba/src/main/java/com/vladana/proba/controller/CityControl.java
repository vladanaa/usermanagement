package com.vladana.proba.controller;

import com.vladana.proba.entity.City;
import com.vladana.proba.service.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CityControl
{
    @Autowired
    private CityService cityService;

    @PostMapping("/addCity")
    public City addCity(@RequestBody City city) {
        return cityService.addCity(city);
    }

    @PostMapping("/addCities")
    public List<City> addCities(@RequestBody List<City> cities) {
        return cityService.addCities(cities);
    }

    @GetMapping("/cities")
    public List<City> getCities() {
        return cityService.getCities();
    }

    @PutMapping("/updateCity")
    public City updateCity(@RequestBody City city) {
        return cityService.updateCity(city);
    }

    @DeleteMapping("/deleteCity/{id}")
    public String deleteCity(@PathVariable int id) {
        return cityService.deleteCity(id);
    }

}
