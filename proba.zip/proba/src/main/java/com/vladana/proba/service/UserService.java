package com.vladana.proba.service;


import com.vladana.proba.entity.User;
import com.vladana.proba.repository.CompanyRepo;
import liquibase.pro.packaged.em;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.vladana.proba.repository.UserRepo;

import javax.management.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class UserService {
    @Autowired
    private UserRepo ur;

    public static boolean validate(String email) {
        Pattern VALID = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = VALID.matcher(email);
        return matcher.find();
    }

    public static boolean isFullname(String str) {
        String reg = "^[a-zA-Z\\.]+";
        return str.matches(reg);
    }


    public static boolean isPass(final String password) {
        String PASSWORD =
                "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#&()–[{}]:;',?/*~$^+=<>]).{8,20}$";
        Pattern pattern = Pattern.compile(PASSWORD);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    public User addUser(User u) {
        if (isFullname(u.getUsername()) &&
                isPass(u.getPassword()) &&
                validate(u.getEmail())) {
            System.out.println("sve ok");
            return ur.save(u);
        }
            System.out.println("nije ok");
            return null;
    }

    public List<User> addUsers(List<User> us){

        return ur.saveAll(us);
    }

    public List<User> getUsers(){
        return ur.findAll();
    }

    public String deleteUser(int id){
        ur.deleteById(id);
        return "User with ID " + id + " succesfully deleted";
    }

    public User updateUser(User user) {
        User temp = ur.findById(user.getId()).orElse(null);
        temp.setUsername(user.getUsername());
        temp.setPassword(user.getPassword());
        temp.setEmail(user.getEmail());
        temp.setName(user.getName());
        temp.setSurname(user.getSurname());
        temp.setBday(user.getBday());
        temp.setSex(user.getSex());
        temp.setBcity(user.getBcity());
        temp.setBcountry(user.getBcountry());
        temp.setCreated(user.getCreated());
        temp.setAactive(user.getAactive());
        return ur.save(temp);
    }


   /* public List<User> findDeactiveUser(String active) {
        return findDeactiveUser(active);}*/


   /* public List<User> getAllFromComp(){
        List<User> users = ur.findAll();;
        ur.findAllById()
    }*/
}


