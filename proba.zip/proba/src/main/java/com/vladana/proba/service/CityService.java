package com.vladana.proba.service;

import com.vladana.proba.entity.City;
import com.vladana.proba.repository.CityRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CityService {

    @Autowired
    private CityRepo r;

    public City addCity(City city){

        return r.save(city);
    }

    public List<City> addCities(List<City> cities){

        return r.saveAll(cities);
    }

    public List<City> getCities(){

        return r.findAll();
    }

    public String deleteCity(int id){
        r.deleteById(id);
        return "City with ID " + id + "succesfully deleted";
    }

    public City updateCity(City city) {
        City temp = r.findById(city.getId()).orElse(null);
        temp.setName(city.getName());
        return r.save(temp);
    }

}
