package com.vladana.proba.controller;

import com.vladana.proba.entity.City;
import com.vladana.proba.entity.Company;
import com.vladana.proba.service.CityService;
import com.vladana.proba.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CompanyControl {

    @Autowired
    private CompanyService companyService;

    @PostMapping("/addCompany")
    public Company addCompany(@RequestBody Company company) {
        return companyService.addCompany(company);
    }

    @PostMapping("/addCompanies")
    public List<Company> addCompanies(@RequestBody List<Company> companies) {
        return companyService.addCompanies(companies);
    }

    @GetMapping("/companies")
    public List<Company> getCompanies() {
        return companyService.getCompanies();
    }

    @PutMapping("/updateCompany")
    public Company updateCompany(@RequestBody Company company) {
        return companyService.updateCompany(company);
    }

    @DeleteMapping("/deleteCompany/{id}")
    public String deleteCompany(@PathVariable int id) {
        return companyService.deleteCompany(id);
    }

}
