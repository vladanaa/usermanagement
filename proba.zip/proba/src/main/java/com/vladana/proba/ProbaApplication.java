package com.vladana.proba;

import com.vladana.proba.controller.CityControl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class ProbaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProbaApplication.class, args);
	}

}
