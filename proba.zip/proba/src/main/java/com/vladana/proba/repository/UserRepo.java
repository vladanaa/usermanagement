package com.vladana.proba.repository;

import com.vladana.proba.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRepo extends JpaRepository<User,Integer> {
    User findByName(String name);

  /*@Query("SELECT * FROM USER WHERE aactive = 0")
    List<User> findDeactiveUser(String active);*/
}
