package com.vladana.proba.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "USER")
public class User {

    @Id
    private int id;
    private String username;
    private String password;
    private String email;
    private String name;
    private String surname;
    private Date bday;
    private String sex;
    private String bcountry;
    private String bcity;
    private Date created;
    private String aactive;

    @ManyToOne(targetEntity = City.class,cascade = CascadeType.ALL)
    @JoinColumn(name = "CityId", referencedColumnName = "id")
    private City city;

    @ManyToOne(targetEntity = Company.class,cascade = CascadeType.ALL)
    @JoinColumn(name = "CompanyId", referencedColumnName = "id")
    private Company company;

}
