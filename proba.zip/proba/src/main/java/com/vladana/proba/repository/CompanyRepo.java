package com.vladana.proba.repository;

import com.vladana.proba.entity.Company;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyRepo extends JpaRepository<Company,Integer> {
    Company findByName(String name);
}
