package com.vladana.proba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProbaApplicationTests {

	@Test
	void contextLoads() {
	}

}
